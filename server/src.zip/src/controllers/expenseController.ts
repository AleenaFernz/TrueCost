import { Request, Response } from "express";
// import { pool } from "../config/db"; // uncomment after DB works

export const createExpense = async (req: Request, res: Response) => {
  try {
    const { description, category, paid_by, amount, currency } = req.body;

    if (!description || !category || !paid_by || !amount || !currency) {
      return res.status(400).json({ error: "All fields are required" });
    }

    // --- Temporary Mock (replace with SQL later) ---
    const newExpense = {
      id: Math.floor(Math.random() * 1000),
      description,
      category,
      paid_by,
      amount,
      currency,
      status: "draft",
    };

    res.status(201).json({
      message: "✅ Expense created successfully",
      expense: newExpense,
    });
  } catch (err) {
    console.error("❌ Error creating expense:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const getMyExpenses = async (req: Request, res: Response) => {
  try {
    // later we’ll fetch using JWT user ID
    const mockExpenses = [
      { id: 1, description: "Hotel stay", amount: 250, status: "Approved" },
      { id: 2, description: "Taxi", amount: 40, status: "Pending" },
    ];

    res.status(200).json({ expenses: mockExpenses });
  } catch (err) {
    console.error("❌ Error fetching expenses:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};
