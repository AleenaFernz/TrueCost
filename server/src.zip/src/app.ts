import express from "express";
import authRoutes from "./routes/authRoutes";

const app = express();

app.use(express.json());
app.use("/api/auth", authRoutes); // ✅ this mounts the route correctly

app.get("/", (req, res) => res.send("Backend running successfully 🚀"));

export default app;
