import express from "express";
import { createExpense, getMyExpenses } from "../controllers/expenseController";

const router = express.Router();

// Create new expense
router.post("/", createExpense);

// Fetch expenses for logged-in user (mock)
router.get("/me", getMyExpenses);

export default router;
